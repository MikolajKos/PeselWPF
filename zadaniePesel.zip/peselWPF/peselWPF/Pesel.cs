﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace peselWPF
{
    class Pesel
    {

        private string numerPesel;

        public string Plec
        {
            get
            {
                char cyfraPlec = numerPesel[9];
                int liczbaPlec = int.Parse(cyfraPlec.ToString());
                if (liczbaPlec % 2 == 0)
                    return "Kobieta";
                else
                    return "Mężczyzna";
            }

        }

        public string Data
        {
            get
            {
                string rok = numerPesel[0].ToString() + numerPesel[1].ToString();
                string wiek = numerPesel[2].ToString();
                string miesiac = numerPesel[3].ToString();
                string dzien = numerPesel[4].ToString() + numerPesel[5].ToString();

                int miesiacInt = int.Parse(miesiac);
                int dzienInt = int.Parse(dzien);
                int wiekInt = int.Parse(wiek);

                if (wiekInt == 9 || wiekInt == 1 || wiekInt == 3 || wiekInt == 5  || wiekInt == 7)
                {
                    miesiac = "1" + miesiac;
                }
                else
                {
                    miesiac = "0" + miesiac;
                }

                switch (wiek)
                {
                    case "8" or "9":
                        return wiek = dzien + "/" + miesiac + "/" + "18" + rok;

                    case "0" or "1":
                        return wiek = dzien + "/" + miesiac + "/" + "19" + rok;

                    case "2" or "3":
                        return wiek = dzien + "/" + miesiac + "/" + "20" + rok;

                    case "4" or "5":
                        return wiek = dzien + "/" + miesiac + "/" + "21" + rok;

                    case "6" or "7":
                        return wiek = dzien + "/" + miesiac + "/" + "22" + rok;

                    default:
                        return "Błąd.";  
                }


            }
        }

        public Pesel(string numer)
        {
            numerPesel = numer;
            WalidacjaNumeruPesel();
        }


        private void WalidacjaIloscZnakow()
        {
            if (numerPesel.Length != 11)
                throw new Exception("Błędna ilość znaków  w numerze.");
        }

        private void WalidacjaPoprawnosciZnakow()
        {

            for (int i = 0; i < numerPesel.Length; i++)
                if (numerPesel[i] < '0' || numerPesel[i] > '9')
                    throw new Exception("Ciąg musi składac się tylko z cyfr.");
        }

        private void WalidacjaCyfryKontrolnej()
        {
            int cyfraKontrolna = int.Parse(numerPesel[10].ToString());
            int[] pesel = new int[10];

            int[] wagaCyfr = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
            int wynik, ostatniaCyfra, liczba1, ostatecznyWynik;
            int suma = 0;
            string wynik_string, sumaString;

            for (int i = 0; i < 10; i++)
                pesel[i] = int.Parse(numerPesel[i].ToString());

            for (int j = 0; j < 10; j++)
            {
                wynik = pesel[j] * wagaCyfr[j];
                if (wynik >= 10)
                {
                    wynik_string = wynik.ToString();
                    ostatniaCyfra = int.Parse(wynik_string[1].ToString());
                    suma = suma + ostatniaCyfra;
                }
                else
                    suma = suma + wynik;
            }
            sumaString = suma.ToString();
            liczba1 = int.Parse(sumaString[1].ToString());

            if (liczba1 == 0)
                ostatecznyWynik = 0;
            else
                ostatecznyWynik = 10 - liczba1;
            
            if (cyfraKontrolna != ostatecznyWynik)
                throw new Exception("Liczba Kontrolna (ostatnia cyfra) jest niepoprawna.");
        }

        private void WalidacjaMiesiaca()
        {
            int numerPesel2 = int.Parse(numerPesel[2].ToString());
            int numerPesel3 = int.Parse(numerPesel[3].ToString());

            if(numerPesel2 == 9 || numerPesel2 == 1 || numerPesel2 == 3 || numerPesel2 == 5 || numerPesel2 == 7)
            {
                if (numerPesel3 > 2)
                    throw new Exception("Podany pesel nie istnieje (nieprawidłowy mieisąc).");
            }

            if(numerPesel2 == 8 || numerPesel2 == 0 || numerPesel2 == 2 || numerPesel2 == 4 || numerPesel2 == 6)
            {
                if(numerPesel3 == 0)
                    throw new Exception("Podany miesiąc wynosi: 0.");
            }
                
        }

        private void WalidacjaDnia()
        {
            /*Walidacja dnia przestępnego*/
            string rok = numerPesel[0].ToString() + numerPesel[1].ToString();
            string wiek = numerPesel[2].ToString();
            string miesiac = numerPesel[3].ToString();
            string dzien = numerPesel[4].ToString() + numerPesel[5].ToString();

            
            int dzienInt = int.Parse(dzien);
            int wiekInt = int.Parse(wiek);

            if (wiekInt == 9 || wiekInt == 1 || wiekInt == 3 || wiekInt == 5 || wiekInt == 7)
            {
                miesiac = "1" + miesiac;
                int miesiacInt = int.Parse(miesiac);

                if (miesiacInt == 10 || miesiacInt == 12)
                    if(dzienInt > 31)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca");
               
                if (miesiacInt == 11)
                    if(dzienInt > 30)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca");
                
                
            }
            else if(wiekInt == 8 || wiekInt == 0 || wiekInt == 2 || wiekInt == 4 || wiekInt == 6)
            {

                string rokWDnia = "";
                int miesiacInt = int.Parse(miesiac);

                if (miesiacInt == 4 || miesiacInt == 6 || miesiacInt == 9)
                    if(dzienInt > 30)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca");

                if (miesiacInt == 1 || miesiacInt == 3 || miesiacInt == 5 || miesiacInt == 7 || miesiacInt == 8)
                    if(dzienInt > 31)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca");

                if (wiekInt == 8 || wiekInt == 9)
                    rokWDnia = "18"+ rok;

                else if (wiekInt == 0 || wiekInt == 1)
                    rokWDnia = "19" + rok;

                else if (wiekInt == 2 || wiekInt == 3)
                    rokWDnia = "20" + rok;

                else if (wiekInt == 4 || wiekInt == 5)
                    rokWDnia = "21" + rok;

                else if (wiekInt == 6 || wiekInt == 7)
                    rokWDnia = "22" + rok;

                int rokWDniaInt = int.Parse(rokWDnia);

                if ((rokWDniaInt % 4 == 0 && rokWDniaInt % 100 != 0) || rokWDniaInt % 400 == 0)
                {
                    if (dzienInt > 29)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca.");
                }
                else
                {
                    if (dzienInt > 28)
                        throw new Exception("Podano zbyt wysoki dzień miesiąca.");
                }

            }
        }

        private void WalidacjaNumeruPesel()
        {
            WalidacjaIloscZnakow();
            WalidacjaPoprawnosciZnakow();
            WalidacjaDnia();
            WalidacjaMiesiaca();
            WalidacjaCyfryKontrolnej();
            
        }



    }
}
